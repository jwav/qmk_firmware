#!/bin/bash
cp ~/Downloads/vee_lily.json ./
# qmk compile vee_lily.json
qmk json2c ./vee_lily.json -o keymap.c

# inserting the content of definitions.c at the beginning of keymap.c
cat definitions.c > temp.c
cat keymap.c >> temp.c
mv temp.c keymap.c

qmk compile
exit 0

