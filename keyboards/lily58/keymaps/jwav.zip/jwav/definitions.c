#include QMK_KEYBOARD_H
#include "french_def.h"

enum custom_keycodes {
    QMKBEST = SAFE_RANGE,
    KC_ECIRC,
    KC_ICIRC,
    KC_OCIRC,
    KC_UCIRC,
    KC_ACIRC,
    MC_DELLINE,
    MC_DELHOME,
    MC_DELEND
};

#define X_DEADCIRC X_LBRC

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    switch (keycode) 
    {
        case KC_ECIRC:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_DEADCIRC)"e");
                break;
            }
        case KC_ICIRC:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_DEADCIRC)"i");
                break;
            }
        case KC_OCIRC:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_DEADCIRC)"o");
                break;
            }
        case KC_UCIRC:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_DEADCIRC)"u");
                break;
            }
        case KC_ACIRC:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_DEADCIRC)"q");
                break;
            }
        case MC_DELLINE:
            if (record->event.pressed) {
                SEND_STRING(SS_TAP(X_HOME));
                SEND_STRING(SS_LSFT(SS_TAP(X_END)));
                SEND_STRING(SS_TAP(X_DEL));
                // SEND_STRING(SS_LCTL(SS_LSFT(SS_TAP(X_DEL))));
                // SEND_STRING(SS_LCTL(SS_LSFT(X_DEL)));
                // tap_code16( 
                break;
            }
        case MC_DELHOME:
            if (record->event.pressed) {
                // SEND_STRING(SS_TAP(X_HOME));
                SEND_STRING(SS_LSFT(SS_TAP(X_HOME)));
                SEND_STRING(SS_TAP(X_DEL));
                // SEND_STRING(SS_LCTL(SS_LSFT(SS_TAP(X_DEL))));
                // SEND_STRING(SS_LCTL(SS_LSFT(X_DEL)));
                // tap_code16( 
                break;
            }
        case MC_DELEND:
            if (record->event.pressed) {
                // SEND_STRING(SS_TAP(X_HOME));
                SEND_STRING(SS_LSFT(SS_TAP(X_END)));
                SEND_STRING(SS_TAP(X_DEL));
                // SEND_STRING(SS_LCTL(SS_LSFT(SS_TAP(X_DEL))));
                // SEND_STRING(SS_LCTL(SS_LSFT(X_DEL)));
                // tap_code16( 
                break;
            }
    }
    return true;
};

//////////////////
////  COMBOS
//////////////////

enum combo_events {
    CB_EACU,
    CB_EGRV,
    CB_AGRV,
    CB_CCED,
    CB_UGRV,

    CB_ECIRC,
    CB_ACIRC,
    CB_OCIRC,
    CB_UCIRC,
};

/*
   &~{<$    |>}=+
   "'[(#    \)]*-
   µ°@_%    `?./!
*/

const uint16_t PROGMEM combo_eacu[] = {fLPRN, fLBRC, COMBO_END};

const uint16_t PROGMEM combo_egrv[] = {fLBRC, fQUOT, COMBO_END};
const uint16_t PROGMEM combo_agrv[] = {fDQUO, fQUOT, COMBO_END};
const uint16_t PROGMEM combo_ugrv[] = {fUNDS, fAT, COMBO_END};

const uint16_t PROGMEM combo_cced[] = {fDEG, fAT, COMBO_END};

const uint16_t PROGMEM combo_ecirc[] = {fLPRN, fHASH, COMBO_END};
const uint16_t PROGMEM combo_acirc[] = {fAMP, fTILD, COMBO_END};
const uint16_t PROGMEM combo_ocirc[] = {fTILD, fLCBR, COMBO_END};
const uint16_t PROGMEM combo_ucirc[] = {fLCBR, fLABK, COMBO_END};


combo_t key_combos[COMBO_COUNT] = {
    [CB_EACU] = COMBO_ACTION(combo_eacu),

    [CB_EGRV] = COMBO_ACTION(combo_egrv),
    [CB_AGRV] = COMBO_ACTION(combo_agrv),
    [CB_UGRV] = COMBO_ACTION(combo_ugrv),

    [CB_CCED] = COMBO_ACTION(combo_cced),

    [CB_ECIRC] = COMBO_ACTION(combo_ecirc),
    [CB_ACIRC] = COMBO_ACTION(combo_acirc),
    [CB_OCIRC] = COMBO_ACTION(combo_ocirc),
    [CB_UCIRC] = COMBO_ACTION(combo_ucirc),
};

void process_combo_event(uint16_t combo_index, bool pressed) {
    switch(combo_index)
    {
        case CB_EACU:
            if (pressed) tap_code16(fEACU);
            break;
        case CB_EGRV:
            if (pressed) tap_code16(fEGRV);
            break;
        case CB_AGRV:
            if (pressed) tap_code16(fAGRV);
            break;
        case CB_CCED:
            if (pressed) tap_code16(fCCED);
            break;
        case CB_UGRV:
            if (pressed) tap_code16(fUGRV);
            break;
        case CB_ECIRC:
            if (pressed) SEND_STRING(SS_TAP(X_DEADCIRC)"e");
            break;
        case CB_ACIRC:
            if (pressed) SEND_STRING(SS_TAP(X_DEADCIRC)"q");
            break;
        case CB_OCIRC:
            if (pressed) SEND_STRING(SS_TAP(X_DEADCIRC)"o");
            break;
        case CB_UCIRC:
            if (pressed) SEND_STRING(SS_TAP(X_DEADCIRC)"u");
            break;
    }
}

