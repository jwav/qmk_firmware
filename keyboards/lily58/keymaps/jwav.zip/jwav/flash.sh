#!/bin/sh
cd ~/qmk_firmware/ && ./flash_jwav.sh
exit 0
#***^^**µµµµ¨¨
