#!/bin/sh
./compile_from_json.sh && ./flash.sh

